MultiDesk v12.6
2023-08-24

https://www.syvik.com/multidesk/

MultiDesk is a tabbed Remote Desktop Connection (Terminal Services Client).


Features:

* Only ONE executable file, small, fast (written in C++), green!
* Portable and SSD/flash drive friendly
* New style: no caption, status bar and fit window with margin
* Manage remote desktop connections in groups
* Inherit username and password from group properties
* Drag and drop support for moving servers and groups
* Tabbed connections
* Connect to console
* Change connection port
* Import cached MSTSC connections
* Import servers by scanning given IP range
* Redirect specified drives
* Quick Connect
* Convenient Full Screen resolution switch
* Compatible with multiple monitors
* Support Remote Desktop Gateway
* Support Master Password
* Support Start Program on connection (Removed from MSTSC on Windows 10)
* Support disable prompts for username and password
* Support SOCKS5 proxy
* Support RDP over VMBus (Hyper-V)
* Support Wake-on-LAN
* Support Windows XP/2003 or higher
* Support high DPI
